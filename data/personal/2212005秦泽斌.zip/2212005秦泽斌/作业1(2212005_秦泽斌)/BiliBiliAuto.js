// ==UserScript==
// @name         Bilibili 自动点赞投币收藏
// @namespace    https://tampermonkey.net/
// @version      1.1
// @description  自动完成哔哩哔哩视频页的点赞、投币、收藏操作。
// @author       2212005秦泽斌
// @match        https://www.bilibili.com/video/*
// @icon         https://www.bilibili.com/favicon.ico
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 轮询等待函数
    function waitForElement(selector, timeout = 10000) {
        return new Promise((resolve, reject) => {
            const interval = 100; // 检查间隔（毫秒）
            let elapsed = 0;

            const check = setInterval(() => {
                const element = document.querySelector(selector);
                if (element) {
                    clearInterval(check);
                    resolve(element);
                } else {
                    elapsed += interval;
                    if (elapsed >= timeout) {
                        clearInterval(check);
                        reject(new Error(`元素 ${selector} 未在 ${timeout / 1000} 秒内加载完成`));
                    }
                }
            }, interval);
        });
    }

    // 自动操作函数
    async function automateActions() {
        console.log("开始自动执行点赞、投币、收藏操作...");

        try {
            const likeButton = await waitForElement(".video-like.video-toolbar-left-item");
            likeButton.click();
            console.log("已点击点赞按钮");

            const coinButton = await waitForElement(".video-coin.video-toolbar-left-item");
            coinButton.click();
            console.log("已点击投币按钮");

            const confirmButton = await waitForElement(".bi-btn");
            confirmButton.click();
            console.log("已点击确认按钮");

            const favButton = await waitForElement(".video-fav.video-toolbar-left-item");
            favButton.click();
            console.log("已点击收藏按钮");

            const defaultFav = await waitForElement(".fav-title");
            defaultFav.click();
            console.log("已选择默认收藏夹");

            const submitButton = await waitForElement(".btn.submit-move");
            submitButton.click();
            console.log("已点击收藏确认按钮");
        } catch (error) {
            console.error("自动操作过程中发生错误：", error);
        }
    }

    // 页面加载完成后执行自动操作
    window.addEventListener("load", () => {
        setTimeout(automateActions, 2000);
    });
})();
